import React from 'react'

export default function Dashboard() {
  return (
    <div>
        <h4>Welcome to Dashboard!</h4>

        </div>
  )
}
